﻿namespace WpfInitApp.Services
{
    public interface ISampleService
    {
        string GetCurrentDate();
    }
}